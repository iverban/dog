export default function Home() {
  return (
    <section className='py-24'>
      <div className='container max-w-5xl'>
        <h1 className='text-2xl font-bold'>NextJs Clerk Shadcn</h1>
        <p className='text-muted-foreground mt-1'>
          NextJs Clerk shadcn/ui starter template.
        </p>
      </div>
    </section>
  )
}
